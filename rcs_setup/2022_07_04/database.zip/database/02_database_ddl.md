

# rcsadmin (rcsadmin1!) 계정으로 접속하여, ddl script 실행

[중요]
03_ddl_prod.sql 실행시, 파티션 생성 쿼리를 실행하여 파티션 부분을 변경 해야 한다!!!

[중요] 
제품 적용시 > 03_ddl_prod.sql
본사 테스트 는 03_ddl_dev.sql 로 만들어져 있다.



이유는 파티션 여부 이다.파티션 관련 정보는 아래 내용 참고.

-- ***********************************************************************
-- 파티션

```sql
select *
from 
	information_schema.PARTITIONS p 
;

alter table '테이블명' add partition (
	partition '파티션명' values less than (파티션 값)
);

alter table alarm_history add partition (
	PARTITION p_2022_08 VALUES LESS THAN  (TO_DAYS('2022-09-01 00:00:00')) ENGINE = InnoDB
);


alter table '테이블명' drop partition '파티션명'
```

```sql
EXPLAIN PARTITIONS 
SELECT * 
FROM 
	audit_log 
WHERE 
	str_reg_ymdt BETWEEN '20201211' AND '20201219';

	
alter table device_log PARTITION BY RANGE (TO_DAYS( create_time )) (
	PARTITION p_2022_07 VALUES LESS THAN  (TO_DAYS('2022-08-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2022_08 VALUES LESS THAN  (TO_DAYS('2022-09-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2022_09 VALUES LESS THAN  (TO_DAYS('2022-10-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2022_10 VALUES LESS THAN  (TO_DAYS('2022-11-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2022_11 VALUES LESS THAN  (TO_DAYS('2022-12-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2022_12 VALUES LESS THAN  (TO_DAYS('2023-01-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2023_01 VALUES LESS THAN  (TO_DAYS('2023-02-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2023_02 VALUES LESS THAN  (TO_DAYS('2023-03-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2023_03 VALUES LESS THAN  (TO_DAYS('2023-04-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2023_04 VALUES LESS THAN  (TO_DAYS('2023-05-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2023_05 VALUES LESS THAN  (TO_DAYS('2023-06-01 00:00:00')) ENGINE = InnoDB,
	PARTITION p_2023_06 VALUES LESS THAN  (TO_DAYS('2023-07-01 00:00:00')) ENGINE = InnoDB
);

WITH RECURSIVE CTE AS (
     SELECT 1 AS DAY
     UNION ALL
     SELECT 1+CTE.DAY AS DAY
     FROM CTE
     WHERE CTE.DAY <= 11
)
select
	concat (
	'PARTITION p_'
-- 	, DATE_FORMAT(now() , '%Y_')
	, DATE_FORMAT(DATE_ADD(NOW(), INTERVAL (day-1) MONTH), '%Y_%m')
	, ' VALUES LESS THAN '
	, ' (TO_DAYS(\''
	, DATE_FORMAT(TIMESTAMPADD(MONTH, day, now()) , '%Y-%m-01 00:00:00')
	, '\')) ENGINE = InnoDB,'
	)
	, day
FROM CTE
```


