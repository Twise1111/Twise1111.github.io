drop table if exists device;
drop table if exists device_history;
drop table if exists device_log;

drop table if exists group_devices;
drop table if exists user_devices;

DROP TABLE IF EXISTS factory;
DROP TABLE IF EXISTS area;
DROP TABLE IF EXISTS bay;

DROP TABLE IF EXISTS rcs_model;
DROP TABLE IF EXISTS resolution;

drop table if exists user_authority;
drop table if exists user;
drop table if exists authority;
drop table if exists user_group;

-- ######################################################################################################
CREATE TABLE factory (
	factory_id bigint NOT NULL AUTO_INCREMENT,
	factory_name varchar(128) NOT NULL,
	CONSTRAINT factory_name_uk1 UNIQUE (factory_name),
	PRIMARY KEY (factory_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8;

CREATE TABLE area (
	area_id bigint NOT NULL AUTO_INCREMENT,
	area_name varchar(128) NOT NULL,
	CONSTRAINT area_name_uk1 UNIQUE (area_name),
	PRIMARY KEY (area_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8;

CREATE TABLE bay (
	bay_id bigint NOT NULL AUTO_INCREMENT,
	bay_name varchar(128) NOT NULL,
	CONSTRAINT bay_name_uk1 UNIQUE (bay_name),
	PRIMARY KEY (bay_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8;

-- ######################################################################################################

CREATE TABLE rcs_model (
	rcs_model_id bigint NOT NULL AUTO_INCREMENT,
	rcs_model_name varchar(128) NOT NULL,
	keyboard bit NOT NULL,
	mouse bit NOT NULL,
	comment varchar(255), 
	control varchar(40),
	rcs_id varchar(128),
  rcs_pass varchar(255),
	CONSTRAINT rcs_model_uk1 UNIQUE (rcs_model_name),
	PRIMARY KEY (rcs_model_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8;

CREATE TABLE resolution (
	resolution_id bigint NOT NULL AUTO_INCREMENT,
	resolution_name varchar(40) NOT NULL,
	width varchar(16) NOT NULL,
	height varchar(16) NOT NULL,
	CONSTRAINT resolution_uk1 UNIQUE (resolution_name),
	PRIMARY KEY (resolution_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8;

-- ######################################################################################################

create table user_group (
	group_id bigint not null auto_increment,
	group_name varchar(40),
	constraint user_group_uk1 unique (group_name),
	primary key (group_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

create table authority (
	auth_id bigint not null auto_increment,
	authority_name varchar(40),
	constraint authority_uk1 unique (authority_name),
	primary key (auth_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

create table user (
	user_id bigint not null auto_increment,
	username varchar(128),
	password varchar(255),
	activated bit not null,
	nickname varchar(128),
	group_id bigint,
	constraint user_uk1 unique (username),
	primary key (user_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

create table user_authority (
	user_auth_id bigint not null auto_increment,
	user_id bigint,
	auth_id bigint,
	primary key (user_auth_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

-- ######################################################################################################
create table device (
	device_id bigint not null auto_increment,
	
	factory varchar(40),
	area varchar(40),
	bay varchar(40),
	target varchar(40),
	machine_name varchar(40) not null,
	
	maker varchar(40),
	model varchar(40),
	
	active bit not null,
	
	rcs_model_id bigint not null,
	rcs_serial_no varchar(40),
	
	ip varchar(40) not null,

	resolution_id bigint not null,
	
	obtain_user_id bigint,
	
	device_status varchar(40),
	
	created_by varchar(128),
	created_date datetime,
	last_modifed_by varchar(128),
	last_modified_date datetime,
	event_comment varchar(255),
	event_name varchar(40),
	
	constraint device_uk1 unique (machine_name),
	constraint device_uk2 unique (ip),
	primary key (device_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

create table device_history (
	device_history_id bigint not null auto_increment,
	device_id bigint,
	
	factory varchar(40),
	area varchar(40),
	bay varchar(40),
	target varchar(40),
	machine_name varchar(40) not null,
	
	maker varchar(40),
	model varchar(40),
	
	active bit not null,
	
	rcs_model_id bigint NOT NULL,
	rcs_serial_no varchar(40),
	
	ip varchar(40),

	resolution_id bigint not null,
	
	action varchar(40),
	created_by varchar(128),
	created_date datetime,
	last_modifed_by varchar(128),
	last_modified_date datetime,
	event_comment varchar(255),
	event_name varchar(40),
	
	key id (device_history_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX device_history_i1 ON device_history (last_modified_date);

create table device_log (
	device_log_id bigint not null auto_increment,
	
	create_time datetime,
	message varchar(255),
	
	group_id bigint,
	group_name varchar(40),
	user_id bigint,
	user_name varchar(128),
	
	device_id bigint,

	factory varchar(40),
	area varchar(40),
	bay varchar(40),
	target varchar(40),
	machine_name varchar(40),	
	ip varchar(40),

	remote_control bit NOT NULL,
	
	key id (device_log_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX device_log_i1 ON device_log (create_time);

-- ######################################################################################################

create table user_devices (
	user_device_id bigint not null auto_increment,
	user_id bigint not null,
	device_id bigint not null,
	primary key (user_device_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX user_devices_i1 ON user_devices (user_id);

create table group_devices (
	group_device_id bigint not null auto_increment,
	group_id bigint not null,
	device_id bigint not null,
	primary key (group_device_id)
) engine=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX group_devices_i1 ON group_devices (group_id);

-- ######################################################################################################
insert into factory (factory_name) values ('S1');

insert into area (area_name) values ('ETCH');
insert into area (area_name) values ('THIN');
insert into area (area_name) values ('DIFF');
insert into area (area_name) values ('IMP');
insert into area (area_name) values ('CLEAN');
insert into area (area_name) values ('CMP');
insert into area (area_name) values ('PHOTO');

insert into bay (bay_name) values ('BAY1');
insert into bay (bay_name) values ('BAY2');
insert into bay (bay_name) values ('BAY3');
insert into bay (bay_name) values ('BAY4');
insert into bay (bay_name) values ('BAY5');
insert into bay (bay_name) values ('BAY6');
insert into bay (bay_name) values ('BAY7');
insert into bay (bay_name) values ('BAY8');
insert into bay (bay_name) values ('BAY9');
insert into bay (bay_name) values ('BAY10');
insert into bay (bay_name) values ('BAY11');
insert into bay (bay_name) values ('BAY12');
insert into bay (bay_name) values ('BAY13');
insert into bay (bay_name) values ('BAY14');
insert into bay (bay_name) values ('BAY15');
insert into bay (bay_name) values ('BAY16');
insert into bay (bay_name) values ('BAY17');
insert into bay (bay_name) values ('BAY18');
insert into bay (bay_name) values ('BAY19');
insert into bay (bay_name) values ('BAY20');
insert into bay (bay_name) values ('BAY21');
insert into bay (bay_name) values ('BAY22');
insert into bay (bay_name) values ('BAY23');
insert into bay (bay_name) values ('BAY24');
insert into bay (bay_name) values ('BAY25');
insert into bay (bay_name) values ('BAY26');
insert into bay (bay_name) values ('BAY27');
insert into bay (bay_name) values ('BAY28');
insert into bay (bay_name) values ('BAY29');
insert into bay (bay_name) values ('BAY30');
insert into bay (bay_name) values ('BAY31');
insert into bay (bay_name) values ('BAY32');
insert into bay (bay_name) values ('BAY33');
insert into bay (bay_name) values ('BAY34');
insert into bay (bay_name) values ('BAY35');
insert into bay (bay_name) values ('BAY36');
insert into bay (bay_name) values ('BAY37');
insert into bay (bay_name) values ('BAY38');
insert into bay (bay_name) values ('BAY39');
insert into bay (bay_name) values ('BAY40');
insert into bay (bay_name) values ('BAY41');
insert into bay (bay_name) values ('BAY42');
insert into bay (bay_name) values ('BAY43');
insert into bay (bay_name) values ('BAY44');
insert into bay (bay_name) values ('BAY45');
insert into bay (bay_name) values ('BAY46');
insert into bay (bay_name) values ('BAY47');
insert into bay (bay_name) values ('BAY48');
insert into bay (bay_name) values ('BAY49');
insert into bay (bay_name) values ('BAY50');

insert into authority (authority_name) values ('ROLE_ADMIN');
insert into authority (authority_name) values ('ROLE_USER');

insert into user_group (group_name) values ('SUPER');
INSERT INTO USER_GROUP (GROUP_NAME) VALUES ('ETCH');
INSERT INTO USER_GROUP (GROUP_NAME) VALUES ('THIN');
INSERT INTO USER_GROUP (GROUP_NAME) VALUES ('DIFF');
INSERT INTO USER_GROUP (GROUP_NAME) VALUES ('IMP');
INSERT INTO USER_GROUP (GROUP_NAME) VALUES ('CLEAN');
INSERT INTO USER_GROUP (GROUP_NAME) VALUES ('CMP');
INSERT INTO USER_GROUP (GROUP_NAME) VALUES ('PHOTO');

-- admin / admin
insert into user (activated, nickname, password, group_id, username) values (true, 'admin', '$2a$10$N.xOGuo0jQle/kOkGyQiten8vJp9OhdAIxsvaEfuYWpbLsrgbR.Ga', 1, 'admin');
-- user1 / user1
insert into user (activated, nickname, password, group_id, username) values (true, 'user1', '$2a$10$1GgdZtc3LKHxAimoydCdSexWaU0dDnrreJR88hrxzqA7mnm5sEM/K', 2, 'user1');

insert into user_authority (user_id, auth_id) values (1, 1);
insert into user_authority (user_id, auth_id) values (1, 2);
insert into user_authority (user_id, auth_id) values (2, 2);

-- admin / admin
-- TRUE : 항상 remoteControl 함
-- ALL : 사용자가 remoteControl 여부 선택 가능
-- FALSE : 항상 remoteControl 하지 않음
INSERT INTO rcs_model (rcs_model_name, keyboard, mouse, comment, control, rcs_id, rcs_pass) VALUES ('100K', 1, 1, 'KVM', 'TRUE', 'administrator', 'ja/rMRSaMv1SmNZidxSyIQ==');
INSERT INTO rcs_model (rcs_model_name, keyboard, mouse, comment, control, rcs_id, rcs_pass) VALUES ('101K', 0, 1, 'Touch', 'ALL', 'administrator', 'ja/rMRSaMv1SmNZidxSyIQ==');
INSERT INTO rcs_model (rcs_model_name, keyboard, mouse, comment, control, rcs_id, rcs_pass) VALUES ('200K', 0, 1, 'Pen', 'ALL', 'administrator', 'ja/rMRSaMv1SmNZidxSyIQ==');

INSERT INTO resolution (resolution_name, width, height) VALUES ('720x400', '720', '400');
INSERT INTO resolution (resolution_name, width, height) VALUES ('640x480', '640', '480');
INSERT INTO resolution (resolution_name, width, height) VALUES ('800x600', '800', '600');
INSERT INTO resolution (resolution_name, width, height) VALUES ('1024x768', '1024', '768');