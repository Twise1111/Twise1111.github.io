# mysql 


/MariaDB 10.6/data/my.ini 파일 [mysqld] 항목에 추가하고, 재시작 한다.

```
max_connections=500
wait_timeout=1805
interactive_timeout=1805
```

```
[mysqld]
datadir=E:/mariadb_data
port=4306
innodb_buffer_pool_size=4053M
character-set-server=utf8
max_connections=500
wait_timeout=1805
interactive_timeout=1805
[client]
port=4306
plugin-dir=C:/Program Files/MariaDB 10.6/lib/plugin
```




mariadb parameter 설정 관련

```
mysql -u root -p

show variables like 'max_connections';
show global variables like 'max_connections';

show variables like 'wait_timeout';
show global variables like 'wait_timeout';

show variables like 'interactive_timeout';
show global variables like 'interactive_timeout';




set wait_timeout = 1805;
set global wait_timeout = 1805;

set interactive_timeout = 1805;
set global interactive_timeout = 1805;

```


create database rcsmgr;


use mysql;
select host,user,password,plugin from user;


CREATE USER rcsadmin@localhost IDENTIFIED by 'rcsadmin1!';
CREATE USER rcsmgr@localhost IDENTIFIED by 'rcsmgr1!';


grant all privileges on rcsmgr.* to rcsadmin@localhost IDENTIFIED by 'rcsadmin1!';
GRANT ALL PRIVILEGES ON rcsmgr.* TO 'rcsadmin'@'%' IDENTIFIED by 'rcsadmin1!';

grant SELECT, INSERT, UPDATE, DELETE on rcsmgr.* to rcsmgr@localhost IDENTIFIED by 'rcsmgr1!';
GRANT SELECT, INSERT, UPDATE, DELETE ON rcsmgr.* TO 'rcsmgr'@'%' IDENTIFIED by 'rcsmgr1!';

FLUSH PRIVILEGES;
