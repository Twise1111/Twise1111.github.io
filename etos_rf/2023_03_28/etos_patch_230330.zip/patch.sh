#!/bin/sh

#SERVICES=`sudo systemctl list-units --type=service --all --state=running | grep EAP | awk '{print $1}'`

SERVICES=`sudo systemctl  --type=service  | grep EAP | awk '{print $NF}'`
TWISE_HOME=/home/twise/etos
BAK_DATE=`date '+%y%m%d%H%M'`

cd $TWISE_HOME
sudo tar cvf $TWISE_HOME/bak/etos_bak_$BAK_DATE.tar config etos_EAP01.jar
sudo chmod 777 $TWISE_HOME/bak/etos_bak_$BAK_DATE.tar
echo  "====== backup finished ===="


for f in $SERVICES 
do
    #echo "sudo systemctl stop $f"
    sudo systemctl stop $f

    #echo "rm -rf /home/twise/etos/etos_$f.jar"
    sudo rm -rf $TWISE_HOME/etos_$f.jar

    sudo cp -rf $TWISE_HOME/patch/config $TWISE_HOME
    #echo"cp -rf  /home/twise/etos/patch/etos.jar /home/twise/etos/etos_$f.jar"
    sudo cp -rf $TWISE_HOME/patch/etos.jar $TWISE_HOME/etos_$f.jar
    sleep 2 
    #echo"systemctl start $f"
    sudo systemctl start $f
    echo "$f patch completed"
done

#sleep 3 
echo  "====== $BAK_DATE patch finished ===="


